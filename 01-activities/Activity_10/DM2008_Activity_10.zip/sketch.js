let angle = 0;
let speed = 0; // Speed of rotation
let palette = ["#f06449", "#009988", "#3c78d8", "#ffeb3b"];
let currentIndex = 0;


function setup() {
  createCanvas(400, 600);
  rectMode(CENTER);
  

  // Slider: controls size
  createP("Speed").position(0, 480).style("margin", "4px 0 0 16px");
  speedSlider = createSlider(0, 100,0,1);
  speedSlider.position(15, 500);

  
  shapeColor = color(random(255), random(255), random(255));

  // Button: change color
  colorBtn = createButton("Change Color");
  colorBtn.position(180, 500);
  colorBtn.mousePressed(randomShapeColor);
  
  colorBtn.addClass('btn'); 
  
  function randomShapeColor() {
    shapeColor = color(random(255), random(255), random(255));
  }
  
  
}

function draw() {
  background("#a2abba");
  let speed = speedSlider.value(); 
  angle += speed;

//Fan
  fill(20);
  ellipse(width / 2, height / 2 -80, 200, 200);
  rect(width/2, 300, 40, 280)
  
  fill(shapeColor);
  ellipse(width / 2, height / 2 -80, 160, 160);
  push();
  translate(width / 2, height / 2 -80);
  rotate(radians(angle));
  drawFlower(0, 0, 50, 50);
  pop();


  
}

//function mousePressed() {
  //currentIndex = (currentIndex + 1) % palette.length;
//}

//function keyPressed() {
//  switch (key) {
//    case 'r':
//      speed = 1;
//     currentIndex = 0;
//  }
//}

function drawFlower(x, y, w, h) {
  noStroke();
  fill("#c0c9cc");
  ellipse(x, y, w, h); 
  fill("#ebf1f2");
  ellipse(x, y - h, w / 3, h * 1.5); 
  ellipse(x, y + h, w / 3, h * 1.5); 
  ellipse(x - w, y, w * 1.5, h / 3); 
  ellipse(x + w, y, w * 1.5, h / 3); 
}

